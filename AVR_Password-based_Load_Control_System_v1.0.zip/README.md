-- Password-based Load Control System -- 

Team: 	NOE S SETENTA JR
	JAH ISAAC CAGULA

Description:
	This project aims to develop a password-based load control system using an AVR microcontroller (Arduino Uno). The system will authenticate users via a 4x4 keypad, and once the correct password is entered, the authorized user can control four LEDs acting as loads. The user can selectively turn ON or OFF any combination of the four LEDs using additional commands on the keypad.

Key Features & Specs
	● Password Authentication
	● Load Control
Input: 
	4X4 Matrix
Output: 
	16x2 I2C LCD
	Relay Module
Microcontroller: 
	Arduino Uno - 16 MHz