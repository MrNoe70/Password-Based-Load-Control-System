#include <avr/io.h>

int main(void) {

char password[5] = "1234";
char input[5] = {0};

if (strncmp(input, password, 4) == 0) {
    LCD_command(0x01);
    LCD_print("Access Granted");
    timer_delay_ms(2000);
    update_lcd_status();

    while (1) {
        key = keypad_getkey();
        if (!key) continue;

        switch (key) {
            case 'A':  // Turn ON all loads (with correct logic for active-low/high)
                set_load(0, 0);  // PB0 active-high (ON)
                set_load(1, 1);  // PB1 active-low (ON = 0)
                set_load(2, 1);  // PB2 active-low (ON = 0)
                set_load(3, 0);  // PB3 active-high (ON)
                break;
                
            case 'B':  // Turn OFF all loads
                set_load(0, 1);  // PB0 active-high (OFF)
                set_load(1, 0);  // PB1 active-low (OFF = 1)
                set_load(2, 0);  // PB2 active-low (OFF = 1)
                set_load(3, 1);  // PB3 active-high (OFF)
                break;
                
            case '1': set_load(0, 0); break;  // Toggle PB0 (active-high)
            case '2': set_load(0, 1); break;
            case '3': set_load(1, 1); break;  // Toggle PB1 (active-low)
            case '4': set_load(1, 0); break;
            case '5': set_load(2, 1); break;  // Toggle PB2 (active-low)
            case '6': set_load(2, 0); break;
            case '7': set_load(3, 0); break;  // Toggle PB3 (active-high)
            case '8': set_load(3, 1); break;
            case 'D': goto reset;
        }
        update_lcd_status();
    }
        } else {
            LCD_command(0xC0);
            LCD_print("Wrong Password");
            timer_delay_ms(2000);
        }

    reset: 
        continue;
    }
